from bs4 import BeautifulSoup

# read the html content
with open('C:\\Users\\LENOVO\\Desktop\\webscrapping\\sample_scrapping.html', 'r') as fo:
    html_content = fo.read()

    
# Creating a BeautifulSoup object
soup = BeautifulSoup(html_content, 'html.parser')

# Using find method to find the first occurrence of <h1> tag
first_h1 = soup.find('h1')
print("First h1 tag:", first_h1.text)

# Using find_all method to find all <p> tags
all_paragraphs = soup.find_all('p')
for paragraph in all_paragraphs:
    print("Paragraph:", paragraph.text)

# Using find method with specific attributes to find the <table> tag
# it will extract the entire table structure with that class name
specific_table = soup.find('table', attrs={'class': 'data-table'})
print("Specific table:", specific_table)

# Using select method to find all <td> elements inside <table> using CSS selector
table_cells = soup.select('table td')
for cell in table_cells:
    print("Table cell:", cell.text)
